mpirun -np 3 ./test_random.x > a.out 
