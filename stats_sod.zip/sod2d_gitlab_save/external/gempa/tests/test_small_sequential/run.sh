mpirun -np 3 ./test_small.x > a.out
 
