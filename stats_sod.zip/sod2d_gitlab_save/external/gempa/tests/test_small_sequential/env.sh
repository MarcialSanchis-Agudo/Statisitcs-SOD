module purgue
module load gcc/7.1.0
module load openmpi/1.10.7
 