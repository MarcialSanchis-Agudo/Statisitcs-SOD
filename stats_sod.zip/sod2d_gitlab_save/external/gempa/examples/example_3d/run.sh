mpirun -np 3 ./example_3d.x  
