mpirun -np 3 ./example_2d.x 
 
