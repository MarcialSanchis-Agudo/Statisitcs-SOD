#!/usr/bin/env python
#
# RSS
#
# Export a hdf5 file with averages and calculate the RSS
#
# Last rev: 28/04/2023
from mpi4py import MPI

import numpy as np
import h5py as h5

comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()
filename ="results_AVGRSS_TGV-1_21.h5"


if rank == 0:
    print("Pre-postproc by rank 0, reading hdf5 file {}".format(rank))
    with h5.File(filename, "r") as f:
        # Print all root level object names (aka keys) 
        # these can be group or dataset names 
        print("Keys: %s" % f.keys())
        
        for keys in range(len(f.keys()))

        # get first object name/key; may or may NOT be a group
        a_group_key = list(f.keys())[0]

        # get the object type for a_group_key: usually group or dataset
        print(type(f[a_group_key])) 

        # If a_group_key is a group name, 
        # this gets the object names in the group and returns as a list
        data = list(f[a_group_key])

        # If a_group_key is a dataset name, 
        # this gets the dataset values and returns as a list
        data = list(f[a_group_key])
        # preferred methods to get dataset values:
        ds_obj = f[a_group_key]      # returns as a h5py dataset object
        ds_arr = f[a_group_key][()]  # returns as a numpy array

        # inputs, moving averages
        avrho = f['u'][:]
        avpre = np.zeros()
        avve2 = np.random.rand(npoin, 3)
        avvex = np.random.rand(npoin, 3)
        avvel = np.random.rand(npoin, 3)
        avpre2 = np.random.rand(npoin)
        avegradU_press = np.random.rand(npoin, 9)
        avegradU_budgets = np.random.rand(npoin, 6)

else:
    print("RSS calculations {}".format(rank))

comm.Barrier

# TKE Budgets
# Production
# Certainly! Here's an example Python code that calculates the turbulent kinetic energy (TKE) budget using the moving averages obtained from the Fortran subroutine:

import numpy as np

# Input parameters (replace with your own values)
# acutim = np.random.rand()
acurho = np.random.rand(npoin)

avrho = np.random.rand(npoin)
avpre = np.random.rand(npoin)
avmueff = np.random.rand(npoin)
avve2 = np.random.rand(npoin, 3)
avvex = np.random.rand(npoin, 3)
avtw = np.random.rand(npoin, 3)
avvel = np.random.rand(npoin, 3)
avpre2 = np.random.rand(npoin)
acugradU_press = np.random.rand(npoin, 9)
avegradU_press = np.random.rand(npoin, 9)
acugradU_budgets = np.random.rand(npoin, 6)
avegradU_budgets = np.random.rand(npoin, 6)

# Calculate TKE budget
rho = acurho + avrho
u = acuve2 + avve2
v = acuvex + avvex
w = acutw + avtw
p = acupre + avpre
mueff = acumueff + avmueff
grad_u = acugradU_budgets + avegradU_budgets
grad_p = acugradU_press + avegradU_press

u_avg = np.mean(u, axis=0)
v_avg = np.mean(v, axis=0)
w_avg = np.mean(w, axis=0)

# Reynolds stresses
for i in range(1,4,1)
    for ipoin in range(len(avvel(:,1)))
        if i == 3
        avR_vw(ipoin) = avvex((ipoin),i) - avvel(lpoin_w(ipoin),2)*avvel(ipoin,3)
        avR_ui2(ipoin) = avve2((ipoin),i) - avvel(lpoin_w(ipoin),i)*avvel(ipoin,i)

        else
        avR_ui2(ipoin) = avve2(ipoin,i) - avvel(ipoin,i)*avvel(ipoin,i)
        avR_vw(ipoin) = avvex(ipoin,i) - avvel(ipoin,1)*avvel(ipoin,i+1)




def turbulent_kinetic_budgets(acugradU_budgets, acugradU_press, avegradU_budgets, avegradU_press, avvel, avve2, avvex, avrho, avpre, avmueff, avtw, avpre2, avvelpr, avvex3, avve3, avve4, dt, dx, dy, dz, nu):

    # Calculate the eddy viscosity
    eddy_visc = nu + avmueff

    # Calculate the terms of the budget
    prod_1 = -(avvel[:, 0] * acugradU_budgets[:, 0, 0] + avvel[:, 1] * acugradU_budgets[:, 0, 1] + avvel[:, 2] * acugradU_budgets[:, 0, 2])
    prod_2 = -(avvel[:, 0] * acugradU_budgets[:, 1, 0] + avvel[:, 1] * acugradU_budgets[:, 1, 1] + avvel[:, 2] * acugradU_budgets[:, 1, 2])
    prod_3 = -(avvel[:, 0] * acugradU_budgets[:, 2, 0] + avvel[:, 1] * acugradU_budgets[:, 2, 1] + avvel[:, 2] * acugradU_budgets[:, 2, 2])
    prod_4 = -(avve2[:, 0] * acugradU_budgets[:, 3, 0] + avve2[:, 1] * acugradU_budgets[:, 3, 1] + avve2[:, 2] * acugradU_budgets[:, 3, 2])
    prod_5 = -(avvex[:, 0] * acugradU_budgets[:, 4, 0] + avvex[:, 1] * acugradU_budgets[:, 4, 1] + avvex[:, 2] * acugradU_budgets[:, 4, 2])
    prod_6 = -(avvel[:, 0] * acugradU_budgets[:, 5, 0] + avvel[:, 1] * acugradU_budgets[:, 5, 1] + avvel[:, 2] * acugradU_budgets[:, 5, 2])
    prod_7 = -(avvex3[:, 0] * acugradU_budgets[:, 6, 0] + avvex3[:, 1] * acugradU_budgets[:, 6, 1] + avvex3[:, 2] * acugradU_budgets[:, 6, 2])
    prod_8 = -(avve3[:, 0] * acugradU_budgets[:, 7, 0] + avve3[:, 1] * acugradU_budgets[:, 7, 1] + avve3[:, 2] * acugradU_budgets[:, 7, 2])
    prod_9 = -(avve4[:, 0] * acugradU_budgets[:, 8, 0] + avve4[:, 1] * acugradU_budgets[:, 8, 1] + avve4[:, 2

